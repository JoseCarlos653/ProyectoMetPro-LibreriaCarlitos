#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <windows.h>

using namespace std;



void menuProducto() // 2
{
	int opcion;
	bool a = true;
	
	while(a)
	{
		cout << "::::Gestion de Productos::::" << endl;
		cout << "1. Agregar Producto" << endl;
		cout << "2. Actualizar Producto" << endl;
		cout << "3. Eliminar Producto" << endl;
		cout << "4. Salir" << endl;
		cout << endl;
		cout << "Ingrese su opcion: ";
		cin >> opcion;
		
		switch(opcion)
		{
			case 1:
				break;
				
			case 2:
				break;
				
			case 3:
				break;
				
			case 4:
				a = false;
				break;
				
			default:
				cout << "Opcion no valida, porfavor vuelva a intentar";
				break;
		}
	}
	
}

void menuCliente() // 3
{
	int opcion;
    bool a = true;
    while(a)
	{
	cout<<"----Clientes----"<< endl;
    cout<<"\n1.Agregar Cliente";
    cout<<"\n2.Editar Cliente";
    cout<<"\n3.Ver Cliente";
    cout<<"\n4.Salir";
    cout <<"\nSu opci�n es: ";
    cin >>opcion;

    switch (opcion)
	{
    	case 1:	break;
    	case 2:	break;
    	case 3: break;
    	case 4:
        a = false;
        break;
		default: cout << "\nOpcion Invalida, Por Favor Intentelo de Nuevo..." << endl << "\n\n"; break;	
	}
	
	}

}

void menuUsuario() // 4
{
	int opcion;
    bool a = true;
    while(a)
	{
	cout<<"----Usuarios----"<< endl;
    cout<<"\n1.Agregar Usuario";
    cout<<"\n2.Editar Usuario";
    cout<<"\n3.Ver Usuario";
    cout<<"\n4.Salir";
    cout <<"\nSu opci�n es: ";
    cin >>opcion;

    switch (opcion)
	{
    	case 1:	break;
    	case 2:	break;
    	case 3: break;
    	case 4:
        a = false;
        break;
		default: cout << "\nOpcion Invalida, Por Favor Intentelo de Nuevo..." << endl << "\n\n"; break;	
	}
	
	}

}


void menuReportes() // 6
{
    int opcion;
    bool a = true;
    
    while(a){
        cout<<"----REPORTES----"<< endl;
        cout<<"\n1.Mostrar Inventario";
        cout<<"\n2.Mostrar Movimientos";
        cout<<"\n3.Mostrar Salidas";
        cout<<"\n4.Salir";
        cout <<"\nSu opci�n es: ";
        cin >>opcion;

        switch (opcion)
        {
        case 1:
            
            break;
        case 2:
            
            break;
        case 3:
            
            break;
        case 4:
            a= false;
            break;
        default:
            break;
        }
    }
}

void menuMovimientos() // 5
{
    int opcion;
    bool a = true;
    while(a){
        cout<<"----Movimientos----"<< endl;
        cout<<"\n1.Agregar Entradas";
        cout<<"\n2.Agregar Salidas ";
        cout<<"\n3.Salir";
        cout <<"\nSu opci�n es: ";
        cin >>opcion;

        switch (opcion)
        {
        case 1:
            
            break;
        case 2:
            
            break;
        case 3:
            a = false;
            break;
        default:
            break;
        }
    }
}

void menu(void) // 1
{
	int opcion;
	bool a = true;
	
	do
	{
		cout << "\t::::Bienvenido a Libreria Carlitos::::" << endl;
	    cout << "1. Gestion de Productos" << endl;
	    cout << "2. Gestion de Clientes" << endl;
	    cout << "3. Gestion de Usuarios" << endl;
	    cout << "4. Movimientos" << endl;
	    cout << "5. Reportes" << endl;
	    cout << "6. Salir" << endl;
	    cout << endl;
	    cout << "Ingrese su opcion: ";
	    cin >> opcion;
	    
	    switch(opcion)
		{
			case 1:
				menuProducto();
				break;
				
			case 2:
				menuCliente();
				break;
				
			case 3:
				menuUsuario();
				break;
				
			case 4:
				menuMovimientos();
				break;
				
			case 5:
				menuReportes();
				break;
				
			case 6:
				a = false;
				break;
				
			default:
				cout << "Opcion no valida, porfavor vuelva a intentar";
				break;	
		}
	    
	} while(a);
}

