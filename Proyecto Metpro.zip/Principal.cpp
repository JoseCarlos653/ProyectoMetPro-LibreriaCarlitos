#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <windows.h>
#include "menu.h"

using namespace std;

void menuProducto(void);

int main()
{
	
	menu();
	
	
	
	
	return 0;
}

